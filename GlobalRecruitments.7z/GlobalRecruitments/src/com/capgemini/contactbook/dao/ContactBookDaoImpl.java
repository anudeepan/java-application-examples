package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.utility.JdbcUtility;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	
	Connection connection = null;
	PreparedStatement statement = null;
	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		logger.info("in getting enquiry details  mehtod..");

		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(Querys.getDetailsFromId);
			statement.setInt(1, EnquiryID);
			ResultSet resultSet=null;
			resultSet = statement.executeQuery();
			resultSet.next();
			
			EnquiryBean ebean = new EnquiryBean();

			ebean.setEnqryId(resultSet.getInt(1));
			ebean.setfName(resultSet.getString(2));
			ebean.setlName(resultSet.getString(3));
			ebean.setContactNo(Long.toString(resultSet.getLong(4)));
			ebean.setpDomain(resultSet.getString(5));
			ebean.setpLocation(resultSet.getString(6));

			return ebean;

		} catch (SQLException e) {
			logger.error("in enquiry details method ex is: " + e.getMessage());
			throw new ContactBookException(" Sorry no details found :-(");
		}
	
	}

	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException
	{
		
		logger.info("in add patient  deatils  method..");
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(Querys.insertQueryToDB);
			statement.setString(1, enqry.getfName());
			statement.setString(2, enqry.getlName());
			statement.setLong(3, Long.parseLong(enqry.getContactNo()));
			statement.setString(4, enqry.getpDomain());
			statement.setString(5, enqry.getpLocation());

			int result = statement.executeUpdate();

			statement = connection.prepareStatement(Querys.getIdFromQuery);
			ResultSet rset = statement.executeQuery();
			rset.next();
			int id=rset.getInt(1);
			return id;

		} catch (SQLException exception) {
			logger.error("Statement not created");
			exception.printStackTrace();
			throw new ContactBookException("Statement not created");

		}	
	}
}
