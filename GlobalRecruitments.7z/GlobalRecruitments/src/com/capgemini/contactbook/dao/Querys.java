package com.capgemini.contactbook.dao;

public class Querys
{
	public static final String insertQueryToDB = "insert into enquiry values(enquiries.nextval,?,?,?,?,?)";
	public static final String getIdFromQuery = "select max(enqryid) from enquiry";
	public static final String getDetailsFromId="select * from enquiry where enqryid=?";

}
