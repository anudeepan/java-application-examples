package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService{

	ContactBookDao contactbookdao=new ContactBookDaoImpl();

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!validateFirstName(enqry.getfName()))
			{
			list.add(" First name should start with capital letter & atleast a 6 characters \n");
		}
		if (!validateLastName(enqry.getlName()))
		{
			list.add(" Last name should be atleast 6 characters \n");
		}
		if (!validateContacNo(enqry.getContactNo())) {
			list.add("Enter a valid contact number \n");
		}
		if(!validatePLocation(enqry.getpLocation()))
		{
			list.add("Enter a valid location with minimum 5 characters \n");
			
		}
		if(!validatePDomain(enqry.getpDomain()))
		{
			list.add("Enter valid domain with min 3 characters \n");
			
		}
		
		if (!list.isEmpty()) {
			result = false;
			throw new ContactBookException(list + "");
		} else {
			result = true;
		}
		return result;
	}
	
	// validating first name
	public boolean validateFirstName(String fName) {
		Pattern pattern = Pattern.compile("[A-Z]{1}[a-zA-Z]{5,20}");
		Matcher matcher = pattern.matcher(fName);
		return matcher.matches();
	}
	
	// validating last name
	public boolean validateLastName(String lName) {
		Pattern pattern = Pattern.compile("[a-zA-Z]{5,20}");
		Matcher matcher = pattern.matcher(lName);
		return matcher.matches();
	}
	
	// validating contact number
	public boolean validateContacNo(String contactNo) {
		Pattern pattern = Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher = pattern.matcher(contactNo);
		return matcher.matches();
	}

	// validating location
	public boolean validatePLocation(String pLocation) {
		Pattern pattern = Pattern.compile("[a-zA-Z]{5,}");
		Matcher matcher = pattern.matcher(pLocation);
		return matcher.matches();
	}
	
	// validating Domain
	public boolean validatePDomain(String pDomain){
		Pattern pattern = Pattern.compile( "[a-zA-Z]{3,}");
		Matcher matcher = pattern.matcher(pDomain);
		return matcher.matches();
	}


	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		
		return contactbookdao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		return contactbookdao.addEnquiry(enqry);
	}
	

}
