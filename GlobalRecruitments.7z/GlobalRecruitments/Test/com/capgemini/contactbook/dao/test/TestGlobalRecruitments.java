package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;


public class TestGlobalRecruitments {

ContactBookDaoImpl dao=null;

@Before
public void test_setUp() {

dao = new ContactBookDaoImpl();
}

@After
public void tear_Down() {

dao = null;
}

//test case for inserting an record
@Test
public void getIdtest() {

EnquiryBean person = new EnquiryBean();

person.setContactNo("9876543210");
person.setfName("Akash");
person.setlName("Kanikaram");
person.setpDomain("cloud");
person.setpLocation("Hyderabad");

try {
Integer id = dao.addEnquiry(person);
assertNotNull(id);

} catch (ContactBookException exception) {
exception.printStackTrace();
}
}

//test case for searching the record through id
@Test
public void testgetEnquiryDetails(){
	
ContactBookDao bookDao = new ContactBookDaoImpl();
EnquiryBean bean;

try {
bean=bookDao.getEnquiryDetails(1001);
assertEquals("Anudeep", bean.getfName());

} catch (ContactBookException exception) {
	
	exception.printStackTrace();
}

}

}
