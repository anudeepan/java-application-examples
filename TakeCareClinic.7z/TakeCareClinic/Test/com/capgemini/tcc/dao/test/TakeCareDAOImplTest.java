package com.capgemini.tcc.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.Patient;
import com.capgemini.tcc.dao.TakeCareDAO;
import com.capgemini.tcc.dao.TakeCareDAOImpl;
import com.capgemini.tcc.exception.TakeCareException;


public class TakeCareDAOImplTest
{
	
	TakeCareDAO dao = null;

	@Before
	public void setUp() {
		dao = new TakeCareDAOImpl();
	}

	@After
	public void tearDown() {
		dao = null;
	}

	@Test
	public void FixAppointmenttest() 
	{

		Patient patient = new Patient();
		patient.setPatientphone(9090909987l);
		patient.setDescription("fever");
		patient.setPatientname("Ravikumar");
		patient.setPatientage(40);
		
		
		try {
			dao.addPatientDetails(patient);

			Integer id = dao.addPatientDetails(patient);
			assertNotNull(id);

		} catch (TakeCareException e) {
			e.printStackTrace();
		}

	}
	
	@Test
	public void searchPatientDetailstest() {

		Patient patient = new Patient();
		try {
			patient=dao.searchPatientDetails(1001);
		} catch (TakeCareException e1) {
			
			e1.printStackTrace();
		}
		
		assertEquals("Hahsujdkah", patient.getPatientname());
		

	}

}
