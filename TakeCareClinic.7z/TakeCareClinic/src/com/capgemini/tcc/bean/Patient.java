package com.capgemini.tcc.bean;

import java.sql.Date;

public class Patient
{
	private int patientid;
	private int patientage;
	private String Patientname;
	private Long patientphone;
	private String description;
	private Date consultdate;
	public int getPatientid() {
		return patientid;
	}
	public void setPatientid(int patientid) {
		this.patientid = patientid;
	}
	public int getPatientage() {
		return patientage;
	}
	public void setPatientage(int patientage) {
		this.patientage = patientage;
	}
	public String getPatientname() {
		return Patientname;
	}
	public void setPatientname(String patientname) {
		Patientname = patientname;
	}
	public Long getPatientphone() {
		return patientphone;
	}
	public void setPatientphone(Long patientphone) {
		this.patientphone = patientphone;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getConsultdate() {
		return consultdate;
	}
	public void setConsultdate(Date consultdate) {
		this.consultdate = consultdate;
	}
	public String toString()
	{
		return "name:"+Patientname+"\nage:"+patientage+"\nphone number:"+patientphone+"\ndescription:"+description+"\nconsultation Date:"+consultdate;
		
	}
	
}
