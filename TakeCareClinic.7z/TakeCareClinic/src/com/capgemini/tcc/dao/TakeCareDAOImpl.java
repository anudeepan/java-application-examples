package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.Patient;
import com.capgemini.tcc.exception.TakeCareException;
import com.capgemini.tcc.utility.JdbcUtility;

public class TakeCareDAOImpl implements TakeCareDAO {
	Connection connection = null;
	PreparedStatement statement = null;
	static Logger logger = Logger.getLogger(TakeCareDAOImpl.class);

	@Override
	public int addPatientDetails(Patient p) throws TakeCareException {

		logger.info("in add patient  deatils  method..");
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryConstants.insertQuery);
			statement.setString(1, p.getPatientname());
			statement.setInt(2, p.getPatientage());
			statement.setLong(3, p.getPatientphone());
			statement.setString(4, p.getDescription());

			int r = statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.getIdQuery);
			ResultSet rs = statement.executeQuery();
			rs.next();
			return rs.getInt(1);

		} catch (SQLException e) {
			logger.error("statement not created..");
			throw new TakeCareException("statement not created");

		}

	}

	@Override
	public Patient searchPatientDetails(int id) throws TakeCareException {

		logger.info("in getting patients details  mehtod..");

		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstants.getPatienDetails);
			statement.setInt(1, id);
			ResultSet resultSet=null;
			
			 resultSet = statement.executeQuery();
			
			
				
			
			resultSet.next();
			Patient p = new Patient();

			p.setPatientid(resultSet.getInt(1));
			p.setPatientname(resultSet.getString(2));
			p.setPatientage(resultSet.getInt(3));
			p.setPatientphone(resultSet.getLong(4));
			p.setDescription(resultSet.getString(5));
			p.setConsultdate(resultSet.getDate(6));

			return p;

		} catch (SQLException e) {
			logger.error("in patient details method ex is: " + e.getMessage());
			throw new TakeCareException(" There is no patient with this ID");
		}

	}
}
