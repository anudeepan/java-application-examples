package com.capgemini.tcc.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.Patient;
import com.capgemini.tcc.exception.TakeCareException;
import com.capgemini.tcc.service.TakeCareService;
import com.capgemini.tcc.service.TakeCareServiceImpl;

public class MainUI {
	static Logger logger = Logger.getLogger(MainUI.class);

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		logger.info("inside main method");
		TakeCareService service = new TakeCareServiceImpl();

		Scanner scanner = new Scanner(System.in);

		// patientService service = new patientServiceImpl();
		while (true)

		{
			System.out
					.println("***********Welcome to Take Care Clinic App**********");
			System.out
					.println("_____________________________________________________");
			System.out.println("1. Add Patient Information");
			System.out.println("2. Search Patient by Id");
			System.out.println("3. EXIT");
			int option=0;
			try
			{
			 option = scanner.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println("Enter only digits:");
			}

			switch (option) {

			case 1:
				scanner.nextLine();
				Patient p = new Patient();

				System.out.println("enter name for patient:");
				String name = scanner.nextLine();
				p.setPatientname(name);
				
				System.out.println("enter age for patient:");
				int age=0;
				try{
				 age = scanner.nextInt();
				}
				catch(InputMismatchException e)
				{
					System.out.println("Enter only digits:");
				}

				p.setPatientage(age);
				System.out.println("enter phone number  for patient:");
				long phonenumber = scanner.nextLong();
				p.setPatientphone(phonenumber);

				System.out.println("enter description for   patients problem");
				scanner.nextLine();
				String description = scanner.nextLine();

				p.setDescription(description);

				try {

					boolean result = service.validateDetails(p);

					if (result) {
						int patientId = service.addPatientDetails(p);
						System.out
								.println("patient information stored successfully for id: "
										+ patientId);
					}

				} catch (TakeCareException e) {
					System.err.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter patient Id for which you want to see details");
				int id=0;
				try{
					id = scanner.nextInt();
				}
				catch(InputMismatchException e)
				{
					System.out.println("enter only digits");
				}
				
				
				
				Patient p1;
				try {
					p1 = service.searchPatientDetails(id);
					System.out.println(p1);

				} catch (TakeCareException e) {

					System.err.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("Thank you for using TAKE CARE APP");
				System.exit(0);
				break;

			default:
				break;
			}

		}

	}

}
