package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.Patient;
import com.capgemini.tcc.dao.TakeCareDAO;
import com.capgemini.tcc.dao.TakeCareDAOImpl;
import com.capgemini.tcc.exception.TakeCareException;


public class TakeCareServiceImpl implements TakeCareService {
	
	TakeCareDAO takecaredao=new TakeCareDAOImpl();
	
	public boolean validateDetails(Patient p) throws  TakeCareException
	{
		
		
		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!isNameValid(p.getPatientname())) {
			list.add("name should start with capital letter & length should be greater than 6 and less tah 20");
		}
		if (!isPhonevalid(p.getPatientphone())) {
			list.add("phone number exactly 10 digits");
		}
		if (!isProblemValid(p.getDescription())) {
			list.add("problem name should contain characters");
		}
		if(!isAgeValid(p.getPatientage()))
		{
			list.add("invalid age");
			
		}
		
		if (!list.isEmpty()) {
			result = false;
			throw new TakeCareException(list + "");
		} else {
			result = true;
		}
		return result;
	}
	
	public boolean isNameValid(String name) {

		String nameRegEx = "[A-Z]{1}[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}

	public boolean isPhonevalid(long mobileNo) {

		String phoneregEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(phoneregEx);
		Matcher matcher = pattern.matcher(String.valueOf(mobileNo));
		return matcher.matches();
	}

	public boolean isProblemValid(String problemName) {

		String nameRegEx = "[a-zA-Z]{3,}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(problemName);
		return matcher.matches();
	}
	public boolean isAgeValid(int age)
	{
		String ageRegEx = "[0-9]{1,3}";
		Pattern pattern = Pattern.compile(ageRegEx);
		
		Matcher matcher = pattern.matcher(String.valueOf(age));
		return matcher.matches();
	}

	@Override
	public int addPatientDetails(Patient p) throws TakeCareException {
		
		return takecaredao.addPatientDetails(p);
		
		
	}

	@Override
	public Patient searchPatientDetails(int id) throws TakeCareException {
		
		return takecaredao.searchPatientDetails(id);
	}

}
